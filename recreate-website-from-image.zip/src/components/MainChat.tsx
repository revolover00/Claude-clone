import { Ghost, Minus, Square, X } from "lucide-react";
import IconButton from "./shared/IconButton";
import ClaudeSpark from "./icons/ClaudeSpark";
import Composer from "./Composer";

export default function MainChat() {
  return (
    <main className="flex h-full min-w-0 flex-1 flex-col bg-shell">
      {/* right window toolbar */}
      <div className="flex h-12 shrink-0 items-center justify-end gap-1 px-2.5">
        <IconButton label="Buddies">
          <Ghost size={18} strokeWidth={1.8} />
        </IconButton>
        <div className="ms-5 flex items-center gap-1.5">
          <IconButton label="Minimize">
            <Minus size={16} strokeWidth={1.9} />
          </IconButton>
          <IconButton label="Maximize">
            <Square size={13} strokeWidth={1.9} />
          </IconButton>
          <IconButton
            label="Close"
            className="hover:bg-[#b43a2e] hover:text-white"
          >
            <X size={17} strokeWidth={1.9} />
          </IconButton>
        </div>
      </div>

      {/* scrollable stage */}
      <div className="scroll-slim min-h-0 flex-1 overflow-y-auto">
        <div className="flex min-h-full flex-col px-6 pb-16">
          {/* plan pill */}
          <div
            className="anim-rise flex justify-center pt-14"
          >
            <div className="inline-flex h-[31px] items-center gap-1.5 rounded-lg border border-line-soft bg-elev-1 px-3 text-[13.5px]">
              <span className="text-ink-muted">Free plan</span>
              <span className="text-ink-faint">·</span>
              <button
                type="button"
                className="font-medium text-link transition-colors duration-150 hover:text-[#9cc6f8] hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-link/50 rounded-sm"
              >
                Upgrade
              </button>
            </div>
          </div>

          {/* centered stack */}
          <div className="flex flex-1 flex-col items-center justify-center pt-10">
            <h1
              className="anim-rise flex items-center gap-3 text-center font-serif text-[clamp(32px,5.2vw,52px)] font-normal leading-[1.1] tracking-[-0.01em] text-[#edeae4]"
            >
              <ClaudeSpark size={46} className="shrink-0 text-accent" />
              <span>Evening, how are things?</span>
            </h1>

            <div className="mt-9 w-full max-w-[690px]">
              <Composer />
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
